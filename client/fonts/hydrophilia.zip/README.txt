©2011 Floodfonts, designed by Felix Braden.

HYDROPHILIA is freeware! You are allowed to use the font(s) for every kind of publication (electronic/print), it doesn't matter if its commercial or not. You can copy and give it away to your friends as long as the README-file is included with the opentype or truetype data. 

It may not be remade or redistributed in any way: it may not be made available for download, it may not be sold, it may not be included in any kind of software collection without the express written permission of the designer.Felix Braden shall, in no event, be liable for any damages arising out of the use or inability to use this font.
I am looking forward to your comments, suggestions and to any information if/how you incorporated this font.



http://www.floodfonts.com
http://twitter.com/floodfonts
https://www.instagram.com/floodfonts
https://www.behance.net/floodfonts
info@felixbraden.de